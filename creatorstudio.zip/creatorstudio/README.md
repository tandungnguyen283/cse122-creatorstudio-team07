# CreatorStudio – Quản lý dự án sáng tạo và phản hồi phiên bản

Đồ án CSE122 – Phát triển ứng dụng web cơ bản. Nguyên mẫu **frontend thuần** (HTML + CSS + JavaScript), không cần máy chủ.

## Chạy thử

Mở `login.html` bằng trình duyệt (hoặc dùng Live Server / `python3 -m http.server`).

Tài khoản demo, mật khẩu chung `123456`:

| Vai trò | Email |
|---|---|
| Khách hàng | client@demo.vn |
| Nhà thiết kế | designer@demo.vn |
| Creative Lead | lead@demo.vn |
| Quản trị viên | admin@demo.vn |

Mẹo demo:
- `?fail=1` trên URL: ép API giả lập trả lỗi để xem trạng thái lỗi + nút Thử lại.
- `?aifail=1` trên URL: ép AI thất bại để xem trạng thái Thử lại / Dùng thủ công / Báo cáo.
- Nút **Đặt lại dữ liệu mẫu** ở trang đăng nhập khôi phục dữ liệu ban đầu.

## Cấu trúc

```text
index.html, login.html, 403.html, 404.html      màn hình dùng chung
client-*.html  designer-*.html  lead-*.html  admin-*.html   12 màn hình theo vai trò
assets/css/styles.css          hệ thống thiết kế dùng chung
assets/js/data.js              dữ liệu giả lập (seed) + dữ liệu cho AI
assets/js/store.js             LocalStorage (CRUD), API giả lập có độ trễ/lỗi, phiên đăng nhập
assets/js/ui.js                khung trang, điều hướng theo vai trò, bảo vệ truy cập, toast, modal, validate
assets/js/ai.js                mô phỏng 3 tính năng AI + giao diện AI chung
assets/js/pages/*.js           logic riêng của từng màn hình
```

## Bảng kiểm kê màn hình

| Vai trò | Mục tiêu người dùng | Nhiệm vụ người dùng | Màn hình | Tệp | CRUD / Trạng thái | AI | Người phụ trách |
|---|---|---|---|---|---|---|---|
| Khách hàng | Brief rõ ràng ngay từ đầu | Mô tả ý tưởng, cấu trúc hóa, lưu nháp, gửi brief | Creative Brief | `client-creative-brief.html` | C/R/U/D(xóa nháp, lưu trữ); nháp → đã gửi → đã duyệt/bị trả | AI-1 Brief Structurer | SV1 |
| Khách hàng | Biết đâu là bản mới nhất và duyệt dễ | Xem phiên bản, góp ý, duyệt / yêu cầu sửa / từ chối | Review Versions | `client-review-versions.html` | C/R/U (góp ý), cập nhật trạng thái phiên bản | – | SV1 |
| Khách hàng | Nắm tiến độ các dự án | Xem tiến độ, tạo/sửa/lưu trữ/xóa dự án | Project Overview | `client-project-overview.html` | C/R/U/D + lưu trữ/khôi phục | – | SV1 |
| Nhà thiết kế | Biết việc cần làm hôm nay | Xem việc được giao, góp ý đang mở | Designer Dashboard | `designer-dashboard.html` | R (+ cập nhật trạng thái việc) | – | SV2 |
| Nhà thiết kế | Định hướng phong cách | Quản lý từ khóa, bảng màu, ô tham chiếu | Moodboard | `designer-moodboard.html` | C/R/U/D, nháp/đã đăng | AI-3 Mood Keyword Assistant | SV2 |
| Nhà thiết kế | Phiên bản không bị nhầm | Tạo, sửa, gửi review, lưu trữ, xử lý góp ý | Version Management | `designer-version-management.html` | C/R/U/D; nháp → chờ review → chờ khách → duyệt/sửa/từ chối/lưu trữ | – | SV2 |
| Creative Lead | Phân công rõ ràng | Giao việc, chuyển cột, duyệt brief | Task Board | `lead-task-board.html` | C/R/U + lưu trữ; todo/doing/review/done | – | SV3 |
| Creative Lead | Chặn lỗi trước khi tới khách | Review nội bộ, checklist, gửi khách hoặc trả lại | Internal Review | `lead-internal-review.html` | C/R/U (góp ý nội bộ), duyệt/trả | – | SV3 |
| Creative Lead | Không bỏ sót feedback | Chọn góp ý, tổng hợp, tạo việc | Feedback Summary | `lead-feedback-summary.html` | C/R/U/D (góp ý, việc) | AI-2 Feedback Summarizer | SV3 |
| Quản trị viên | Brief đầy đủ trường | Tạo/sửa/vô hiệu hóa/xóa template | Brief Template Mgmt | `admin-brief-template-management.html` | C/R/U/D; đang dùng/vô hiệu hóa | – | SV3 |
| Quản trị viên | Kiểm soát tài khoản | Thêm, đổi vai trò, vô hiệu hóa | User Management | `admin-user-management.html` | C/R/U; hoạt động/vô hiệu hóa | – | SV3 |
| Quản trị viên | Quy tắc từng dự án | Phân công nhân sự, quy tắc duyệt, lưu trữ/xóa | Project Settings | `admin-project-settings.html` | C/R/U/D; khóa khi lưu trữ | – | SV3 |
| Dùng chung | Vào đúng khu vực | Giới thiệu, đăng nhập, chặn quyền, 404 | Index / Login / 403 / 404 | `index.html` `login.html` `403.html` `404.html` | Lỗi đăng nhập, tài khoản bị vô hiệu hóa, đang tải | – | SV1 + SV3 |

Chưa làm (cần thảo luận với giảng viên trong bảng kiểm kê): `register`, `forgot-password`, `profile`, `settings`, `notifications`.

## Luồng nghiệp vụ chính

```text
Khách hàng: mô tả → AI-1 → lưu nháp → gửi brief
Lead: duyệt brief → giao việc
Designer: moodboard (AI-3) → tạo phiên bản → gửi review
Lead: checklist → gửi khách (phiên bản này thành "Mới nhất")
Khách hàng: duyệt / yêu cầu sửa / từ chối + góp ý
Lead: chọn góp ý → AI-2 → tạo việc → Designer sửa → lặp lại
```

## Bao phủ trạng thái

| Trạng thái | Nơi thể hiện |
|---|---|
| Đang tải | Khung xương ở mọi danh sách (API giả lập trễ ~450 ms); AI hiển thị "AI đang xử lý" |
| Rỗng | Mọi danh sách có thông điệp + nút hành động (vd. chưa có dự án, phiên bản, góp ý) |
| Lỗi | `?fail=1` → thông báo lỗi + Thử lại; lỗi validate cạnh từng ô |
| Thành công | Toast sau mỗi thao tác |
| Vô hiệu hóa | Nút duyệt khi không phải bản mới nhất; không thể tự vô hiệu hóa chính mình; dự án đã lưu trữ khóa form |
| Đang chờ / Bị từ chối / Hoàn thành / Đã lưu trữ | Nhãn trạng thái cho brief, phiên bản, việc, dự án |

## Trải nghiệm AI

Cả 3 AI theo luồng: Nhập → Kiểm tra hợp lệ → Đang xử lý → Kết quả → Vì sao có kết quả này → Chấp nhận / Sửa / Từ chối / Tạo lại → Lưu vào trạng thái ứng dụng.

| AI | Mô phỏng | Tác động nghiệp vụ | Trạng thái thất bại |
|---|---|---|---|
| AI-1 Brief Structurer | Luật + từ khóa trong `ai.js` | Điền biểu mẫu brief | Mô tả < 25 ký tự; độ tin cậy thấp; `?aifail=1` |
| AI-2 Feedback Summarizer | Luật ưu tiên theo từ khóa, gộp mục trùng | Tạo việc trên Task Board, đánh dấu góp ý đã xử lý | < 2 góp ý; `?aifail=1`; có nút Dùng thủ công |
| AI-3 Mood Keyword Assistant | Từ điển phong cách | Thêm từ khóa vào moodboard | Chủ đề không nhận diện được; `?aifail=1` |

## Dữ liệu

Entity: `users, projects, briefs, moodboards, versions, comments, tasks, templates`. Seed ở `assets/js/data.js`, lưu vào LocalStorage (khóa `creatorstudio_db_v1`).

## Git (gợi ý)

```text
main ← dev ← feature/<tên-màn-hình>
feature/client-creative-brief        (SV1)
feature/designer-moodboard           (SV2)
feature/lead-feedback-summary        (SV3)
```

Mỗi màn hình hoàn thành: Figma/Canva → HTML → CSS → JS → dữ liệu → responsive → PR → đánh giá chéo → merge `dev` → OBS.

> Lưu ý: bảng "Người phụ trách" theo phân công mặc định SV1/SV2/SV3 của đề; nhóm cần chốt lại và tự thực hiện Figma/Canva, PR GitHub, video OBS.
