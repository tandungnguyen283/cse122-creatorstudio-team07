(function () {
  const user = CS.ui.init(); if (!user) return;
  const $ = (id) => document.getElementById(id);
  const esc = CS.ui.esc;
  const SAMPLE = "Tôi cần logo và danh thiếp cho quán cà phê, phong cách tối giản và ấm áp, dành cho sinh viên. Ngân sách 20 triệu, cần xong trước 15/11.";
  let pid = CS.ui.getProjectId(user);
  let editingId = null;
  let aiResult = null;

  if (!pid) {
    CS.ui.state($("briefList"), "empty", { icon: "📁", msg: "Bạn chưa có dự án nào." });
    return;
  }
  CS.ui.projectPicker(user, $("projectSelect"), (id) => { pid = id; resetForm(); renderList(); });

  /* ---------- AI-1 ---------- */
  function runAI() {
    const ta = $("freeText"); const err = $("freeTextErr");
    err.textContent = "";
    if (ta.value.trim().length < 25) {
      ta.setAttribute("aria-invalid", "true");
      err.textContent = "Hãy mô tả ít nhất 25 ký tự để AI có đủ dữ liệu.";
      ta.focus(); return;
    }
    ta.setAttribute("aria-invalid", "false");
    const out = $("aiOut");
    $("runAI").disabled = true;
    CS.AI.ui.processing(out);
    CS.AI.structureBrief(ta.value).then((r) => {
      aiResult = r; renderAIResult(r);
    }).catch((e) => {
      CS.AI.ui.failure(out, e);
      out.querySelector("[data-ai-retry]").onclick = runAI;
      out.querySelector("[data-ai-manual]").onclick = () => { out.innerHTML = ""; $("fTitle").focus(); };
      out.querySelector("[data-ai-report]").onclick = CS.AI.ui.report;
    }).finally(() => { $("runAI").disabled = false; });
  }

  function renderAIResult(r) {
    const b = r.brief;
    const rows = [
      ["Mục tiêu", b.goal], ["Đối tượng", b.audience], ["Sản phẩm", b.deliverables.join(", ")],
      ["Phong cách", b.style.join(", ")], ["Ngân sách", b.budget ? b.budget + " VNĐ" : ""], ["Hạn chót", CS.ui.fmtDate(b.deadline)]
    ].map(([k, v]) => `<tr><th scope="row">${k}</th><td>${v ? esc(v) : '<span class="badge warn">Thiếu</span>'}</td></tr>`).join("");
    $("aiOut").innerHTML = `<div class="ai-result">
      ${r.low ? '<div class="alert warn">AI chưa chắc chắn về kết quả này. Hãy kiểm tra kỹ hoặc bổ sung: ' + esc(r.missing.join(", ")) + '.</div>' : ""}
      <div class="table-wrap"><table><tbody>${rows}</tbody></table></div>
      ${CS.AI.ui.why(r.why, r.confidence, r.low)}
      <div class="actions" style="margin-top:.8rem">
        <button class="btn ok sm" id="aiAccept">Chấp nhận</button>
        <button class="btn sm" id="aiEdit">Sửa</button>
        <button class="btn sm" id="aiRegen">Tạo lại</button>
        <button class="btn danger sm" id="aiReject">Từ chối</button>
      </div></div>`;
    $("aiAccept").onclick = () => { fillForm(aiResult.brief, true); CS.ui.toast("Đã đưa kết quả AI vào biểu mẫu. Bấm Lưu nháp để lưu.", "ok"); };
    $("aiEdit").onclick = () => { fillForm(aiResult.brief, true); $("fTitle").focus(); };
    $("aiRegen").onclick = runAI;
    $("aiReject").onclick = () => { $("aiOut").innerHTML = '<p class="hint" style="color:var(--muted)">Đã bỏ kết quả AI. Bạn có thể nhập lại hoặc điền thủ công.</p>'; aiResult = null; };
  }

  function fillForm(b, fromAI) {
    if (fromAI && !$("fTitle").value) $("fTitle").value = (b.deliverables[0] || "Brief") + " – " + (b.goal || "").slice(0, 30);
    $("fGoal").value = b.goal || "";
    $("fAudience").value = b.audience || "";
    $("fDeliverables").value = (b.deliverables || []).join(", ");
    $("fStyle").value = (b.style || []).join(", ");
    $("fBudget").value = b.budget || "";
    $("fDeadline").value = b.deadline || "";
  }

  /* ---------- Biểu mẫu (C/U) ---------- */
  const form = $("briefForm");
  let mode = "draft";
  form.querySelectorAll("button[type=submit]").forEach((btn) => btn.addEventListener("click", () => { mode = btn.dataset.mode; }));
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!CS.ui.validate(form)) { CS.ui.toast("Vui lòng kiểm tra các trường báo lỗi.", "err"); return; }
    const split = (s) => s.split(",").map((x) => x.trim()).filter(Boolean);
    const data = {
      projectId: pid, title: $("fTitle").value.trim(), goal: $("fGoal").value.trim(), audience: $("fAudience").value.trim(),
      deliverables: split($("fDeliverables").value), style: split($("fStyle").value), budget: $("fBudget").value.trim(),
      deadline: $("fDeadline").value, status: mode === "submit" ? "submitted" : "draft", createdBy: user.id
    };
    if (editingId) CS.store.update("briefs", editingId, data); else CS.store.add("briefs", data);
    CS.ui.toast(mode === "submit" ? "Đã gửi brief cho Creative Lead." : "Đã lưu nháp.", "ok");
    resetForm(); renderList();
  });
  $("resetForm").onclick = resetForm;
  function resetForm() {
    form.reset(); editingId = null; $("editBadge").hidden = true;
    form.querySelectorAll(".field-error").forEach((e) => (e.textContent = ""));
    form.querySelectorAll("[aria-invalid]").forEach((e) => e.removeAttribute("aria-invalid"));
  }
  $("runAI").onclick = runAI;
  $("fillSample").onclick = () => { $("freeText").value = SAMPLE; $("freeText").focus(); };

  /* ---------- Danh sách (R) + xóa/lưu trữ (D) ---------- */
  function renderList() {
    const host = $("briefList");
    CS.ui.state(host, "loading");
    CS.api.list("briefs", (b) => b.projectId === pid && b.status !== "archived").then((rows) => {
      if (!rows.length) { CS.ui.state(host, "empty", { icon: "📝", msg: "Chưa có brief nào cho dự án này. Hãy tạo brief đầu tiên ở phía trên." }); return; }
      host.innerHTML = '<div class="grid auto">' + rows.map((b) => `
        <article class="card" aria-label="${esc(b.title)}">
          <div style="display:flex;justify-content:space-between;gap:.5rem"><h3>${esc(b.title)}</h3>${CS.ui.statusBadge(b.status)}</div>
          <p>${esc(b.goal)}</p>
          <p class="hint" style="color:var(--muted);font-size:.85rem">Hạn: ${CS.ui.fmtDate(b.deadline)} · ${esc((b.deliverables || []).join(", "))}</p>
          <div class="actions">
            ${b.status === "draft" || b.status === "rejected" ? `<button class="btn sm" data-act="edit" data-id="${b.id}">Sửa</button><button class="btn sm primary" data-act="submit" data-id="${b.id}">Gửi</button>` : ""}
            ${b.status === "draft" ? `<button class="btn sm danger" data-act="delete" data-id="${b.id}">Xóa</button>` : `<button class="btn sm" data-act="archive" data-id="${b.id}">Lưu trữ</button>`}
          </div>
        </article>`).join("") + "</div>";
    }).catch((e) => CS.ui.state(host, "error", { msg: e.message, onRetry: renderList }));
  }

  $("briefList").addEventListener("click", (e) => {
    const btn = e.target.closest("[data-act]"); if (!btn) return;
    const id = btn.dataset.id; const act = btn.dataset.act;
    if (act === "edit") {
      const b = CS.store.get("briefs", id); editingId = id;
      $("fTitle").value = b.title; fillForm(b, false); $("editBadge").hidden = false; $("fTitle").focus();
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else if (act === "submit") {
      CS.store.update("briefs", id, { status: "submitted" }); CS.ui.toast("Đã gửi brief.", "ok"); renderList();
    } else if (act === "delete") {
      if (CS.ui.confirm("Xóa bản nháp này?")) { CS.store.remove("briefs", id); CS.ui.toast("Đã xóa bản nháp."); renderList(); }
    } else if (act === "archive") {
      CS.store.update("briefs", id, { status: "archived" }); CS.ui.toast("Đã lưu trữ brief."); renderList();
    }
  });

  renderList();
})();
