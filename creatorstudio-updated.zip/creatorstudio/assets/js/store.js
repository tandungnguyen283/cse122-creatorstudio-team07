/* Lớp dữ liệu: LocalStorage + API giả lập có độ trễ/lỗi để minh họa trạng thái đang tải/lỗi/rỗng. */
(function () {
  const KEY = "creatorstudio_db_v1";
  const SESSION = "creatorstudio_session_v1";

  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) { /* bỏ qua, dùng seed */ }
    return JSON.parse(JSON.stringify(CS.SEED));
  }
  let db = load();
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(db)); } catch (e) { /* hết dung lượng: giữ trong bộ nhớ */ }
  }
  function uid(prefix) { return prefix + Math.random().toString(36).slice(2, 8); }

  const store = {
    list(entity) { return (db[entity] || []).slice(); },
    get(entity, id) { return (db[entity] || []).find((x) => x.id === id) || null; },
    add(entity, obj) {
      const rec = Object.assign({ id: uid(entity[0]) }, obj);
      db[entity] = db[entity] || [];
      db[entity].push(rec); save(); return rec;
    },
    update(entity, id, patch) {
      const rec = store.get(entity, id);
      if (!rec) return null;
      Object.assign(rec, patch); save(); return rec;
    },
    remove(entity, id) {
      db[entity] = (db[entity] || []).filter((x) => x.id !== id); save();
    },
    reset() { db = JSON.parse(JSON.stringify(CS.SEED)); save(); },
    clearAll() { db.briefs = []; db.versions = []; db.comments = []; db.tasks = []; save(); }
  };

  /* API giả lập: trả Promise, có thể bật lỗi bằng ?fail=1 trên URL để demo trạng thái lỗi. */
  const api = {
    delay: 450,
    list(entity, filterFn) {
      const forceFail = new URLSearchParams(location.search).get("fail") === "1";
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          if (forceFail) return reject(new Error("Không thể tải dữ liệu. Vui lòng thử lại."));
          const rows = store.list(entity);
          resolve(filterFn ? rows.filter(filterFn) : rows);
        }, api.delay);
      });
    }
  };

  const session = {
    get() { try { return JSON.parse(localStorage.getItem(SESSION)); } catch (e) { return null; } },
    login(userId) {
      const u = store.get("users", userId);
      if (!u) return null;
      localStorage.setItem(SESSION, JSON.stringify({ userId: u.id, role: u.role }));
      return u;
    },
    /* Băm đơn giản (nguyên mẫu, không dùng cho hệ thống thật) để không lưu mật khẩu dạng chữ thường. */
    hash(email, pw) {
      let h1 = 0xdeadbeef, h2 = 0x41c6ce57; const str = email.toLowerCase() + "\u0000" + pw;
      for (let i = 0; i < str.length; i++) { const c = str.charCodeAt(i); h1 = Math.imul(h1 ^ c, 2654435761); h2 = Math.imul(h2 ^ c, 1597334677); }
      h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
      h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
      return (h2 >>> 0).toString(16) + (h1 >>> 0).toString(16);
    },
    logout() { localStorage.removeItem(SESSION); },
    user() { const s = session.get(); return s ? store.get("users", s.userId) : null; }
  };

  CS.store = store; CS.api = api; CS.session = session; CS.uid = uid;
})();
